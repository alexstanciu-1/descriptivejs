
var $data_to_test = {
		data: {
			text: '01',
			item: {
					text: '01 - 01',
					item: {
						text: '01 - 02',
					}
				}
		}
	};
