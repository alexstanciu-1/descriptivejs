
var $children = [];

for (var $i = 0; $i < 1000; $i++)
	$children.push({text: 'node #' + ($i + 1)});

var $data_to_test = {
		children: $children
	};
