
var $data_to_test = {
		children: [
			{text: 'node01'},
			{text: 'node02'},
			{text: 'node03'}, 
			{text: 'node04'},
			{text: 'node05'}
		],
		
		items: [
			{text: 'item #01'},
			{text: 'item #02'},
			{text: 'item #03'}, 
			{text: 'item #04'},
			{text: 'item #05'}
		],
		
		misc_test: {
			text: 'this is a test!'
		}
		
	};
