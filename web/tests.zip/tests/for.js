
var $data_to_test = {
		children: [
			{text: 'node01'},
			{text: 'node02'},
			{text: 'node03'}, 
			{text: 'node04'},
			{text: 'node05'}
		]
	};
