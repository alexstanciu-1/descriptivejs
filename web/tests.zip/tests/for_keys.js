
var $data_to_test = {
		children: [
			{text: 'node01', level: 0},
			{text: 'node02', level: 0},
			{text: 'node03', level: 0}, 
			{text: 'node04', level: 0},
			{text: 'node05', level: 0}
		]
	};
