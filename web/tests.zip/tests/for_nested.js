
var $data_to_test = {
		children: [
			{text: 'node01', 
				children: [
					{text: 'sub-node-01 --- 01'},
					{text: 'sub-node-01 --- 02',
						children: [
							{text: 'SUB sub-node-01 --- 01'},
							{text: 'SUB sub-node-01 --- 02'}
						]
					},
					{text: 'sub-node-01 --- 03'}
				]},
			{text: 'node02'},
			{text: 'node03', 
				children: [
					{text: 'sub-node-03 --- 01'},
					{text: 'sub-node-03 --- 02'},
					{text: 'sub-node-03 --- 03'}
				]},
			{text: 'node04'},
			{text: 'node05'}
		]
	};
	