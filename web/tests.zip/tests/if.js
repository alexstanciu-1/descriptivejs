
var $data_to_test = {
	data: {
		myText: 'The IF text!'
	}
};
